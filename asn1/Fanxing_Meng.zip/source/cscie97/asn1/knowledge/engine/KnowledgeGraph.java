package cscie97.asn1.knowledge.engine;

import java.util.Map;
import java.util.TreeMap;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class KnowledgeGraph{

	private static KnowledgeGraph graph = new KnowledgeGraph();
	private static Map<String, Node> nodeMap = new TreeMap<String, Node>(String.CASE_INSENSITIVE_ORDER);;
	private static Map<String, Predicate> predicateMap = new TreeMap<String, Predicate>(String.CASE_INSENSITIVE_ORDER);
	private static Map<String, Triple> tripleMap = new TreeMap<String, Triple>(String.CASE_INSENSITIVE_ORDER);
	private static Map<String, Set<Triple>> queryMapSet = new TreeMap<String, Set<Triple>>(String.CASE_INSENSITIVE_ORDER);

	public static void importTriples(List<Triple> tripleList){
		for(int i = 0; i < tripleList.size(); i++){
			nodeMap.put(tripleList.get(i).getSubject().getIdentifier(), tripleList.get(i).getSubject());
			nodeMap.put(tripleList.get(i).getObject().getIdentifier(), tripleList.get(i).getObject());
			predicateMap.put(tripleList.get(i).getPredicate().getIdentifier(), tripleList.get(i).getPredicate());
			tripleMap.put(tripleList.get(i).getIdentifier(), tripleList.get(i));
			String[] queryOption = {
				tripleList.get(i).getIdentifier(),
				tripleList.get(i).getSubject().getIdentifier() + " " + tripleList.get(i).getPredicate().getIdentifier() + " " + "?",
				tripleList.get(i).getSubject().getIdentifier() + " " + "?" + " " + tripleList.get(i).getObject().getIdentifier(),
				"?" + " " + tripleList.get(i).getPredicate().getIdentifier() + " " + tripleList.get(i).getObject().getIdentifier(),
				tripleList.get(i).getSubject().getIdentifier() + " " + "?" + " " + "?",
				"?" + " " + tripleList.get(i).getPredicate().getIdentifier() + " " + "?",
				"?" + " " + "?" + " " + tripleList.get(i).getObject().getIdentifier(),
				"?" + " " + "?" + " " + "?"
			};
			for(int j = 0; j < 8; j++){		
				if(queryMapSet.get(queryOption[j]) == null){
					Set<Triple> tripleSet = new HashSet<Triple>();
					tripleSet.add(tripleList.get(i));
					queryMapSet.put(queryOption[j], tripleSet);
				}
				else{		
					queryMapSet.get(queryOption[j]).add(tripleList.get(i));
					queryMapSet.put(queryOption[j], queryMapSet.get(queryOption[j]));			
				}
			}	
		}
	}
	public static Set<Triple> executeQuery(Triple query){
		String queryString = query.getSubject().getIdentifier() + " " + query.getPredicate().getIdentifier() + " " + query.getObject().getIdentifier();
		return queryMapSet.get(queryString);
	}
	public static KnowledgeGraph getInstance(){
		return graph;
	}
	public static Node getNode(String identifier){
		if(nodeMap.get(identifier) != null)
			return nodeMap.get(identifier);
		else{
			nodeMap.put(identifier, new Node(identifier));
			return nodeMap.get(identifier);
		}
	}
	public static Predicate getPredicate(String identifier){
		if(predicateMap.get(identifier) != null)
			return predicateMap.get(identifier);
		else{
			predicateMap.put(identifier, new Predicate(identifier));
			return predicateMap.get(identifier);
		}
	}
	public static Triple getTriple(Node subject, Predicate predicate, Node object){
		if(tripleMap.get(subject.getIdentifier() + " " + predicate.getIdentifier() + " " + object.getIdentifier()) != null)
			return tripleMap.get(subject.getIdentifier() + " " + predicate.getIdentifier() + " " + object.getIdentifier());
		else{
			tripleMap.put(subject.getIdentifier() + " " + predicate.getIdentifier() + " " + object.getIdentifier(), new Triple(subject, predicate, object));
			return tripleMap.get(subject.getIdentifier() + " " + predicate.getIdentifier() + " " + object.getIdentifier());
		}
	}
}
