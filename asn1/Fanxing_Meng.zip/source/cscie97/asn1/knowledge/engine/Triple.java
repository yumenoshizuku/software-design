package cscie97.asn1.knowledge.engine;

public class Triple{
	private String identifier;
	private Node subject;
	private Predicate predicate;
	private Node object;

	public Triple(Node newSubject, Predicate newPredicate, Node newObject){
		subject = newSubject;
		predicate = newPredicate;
		object = newObject;
	}
	
	public String getIdentifier(){
		identifier = subject.getIdentifier() + " " +predicate.getIdentifier() + " " + object.getIdentifier();
		return identifier;
	}
	public Node getSubject(){
		return subject;
	}
	public Predicate getPredicate(){
		return predicate;
	}
	public Node getObject(){
		return object;
	}
}
