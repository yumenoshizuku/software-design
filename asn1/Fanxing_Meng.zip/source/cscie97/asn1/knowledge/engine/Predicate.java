package cscie97.asn1.knowledge.engine;

public class Predicate{
	private String identifier;

	public Predicate(String newId){
		identifier = newId;
	}

	public String getIdentifier(){
		return identifier;
	}
	
}
