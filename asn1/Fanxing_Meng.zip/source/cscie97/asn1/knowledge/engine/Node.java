package cscie97.asn1.knowledge.engine;

public class Node{
	private String identifier;

	public Node(String newId){
		identifier = newId;
	}

	public String getIdentifier(){
		return identifier;
	}
}
