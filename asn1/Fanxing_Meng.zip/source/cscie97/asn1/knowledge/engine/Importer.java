package cscie97.asn1.knowledge.engine;

import java.io.*;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Importer{
	public static void importTripleFile(String fileName){
		try{
			File inputFile = new File(fileName);
			FileReader fileReader = new FileReader(inputFile);
			BufferedReader reader = new BufferedReader(fileReader);
			List<Triple> tripleList = new ArrayList<Triple>();
			String inputText = null;
			while((inputText = reader.readLine()) != null){
				String[] inputLine = inputText.split("[\\n]");
				for(String currentLine : inputLine){
					if(currentLine.length()!=0){
					String[] inputToken = currentLine.split("[\\s \\.]");
/*	Don't work?		Pattern idPattern = Pattern.compile("\\w*\\s");  
    				Matcher isSId = idPattern.matcher(inputToken[0]);
    				Matcher isPId = idPattern.matcher(inputToken[1]);
    				Matcher isOId = idPattern.matcher(inputToken[2]);
					System.out.println(inputToken[0]);
					System.out.println(inputToken[1]);
					System.out.println(inputToken[2]);
    				if(isSId.matches() && isPId.matches() && isOId.matches()){
*/					tripleList.add(KnowledgeGraph.getTriple(KnowledgeGraph.getNode(inputToken[0]), KnowledgeGraph.getPredicate(inputToken[1]), KnowledgeGraph.getNode(inputToken[2])));
/*					}
					else{
						System.out.println("Incorrect input format: " + inputLine);
					}
*/					}
				}
			KnowledgeGraph.getInstance().importTriples(tripleList);
			}
			reader.close();
		}	catch(Exception ex){
				System.out.print("Exception: " + ex);
			}
	}
}
