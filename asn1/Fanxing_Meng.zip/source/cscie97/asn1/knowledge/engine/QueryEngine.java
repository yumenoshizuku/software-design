package cscie97.asn1.knowledge.engine;

import java.io.*;
import java.util.Set;
import java.util.Iterator;

public class QueryEngine{
	public static void executeQuery(String query){
		String[] queryToken = query.split("[\\s\\.]");
		Node querySubject = KnowledgeGraph.getNode(queryToken[0]);
		Predicate queryPredicate = KnowledgeGraph.getPredicate(queryToken[1]);
		Node queryObject = KnowledgeGraph.getNode(queryToken[2]);
		Triple queryTriple = KnowledgeGraph.getTriple(querySubject, queryPredicate, queryObject);
		System.out.println(query + ".");
		Set<Triple> resultSet = KnowledgeGraph.executeQuery(queryTriple);
		if(resultSet != null){
			Iterator it = resultSet.iterator();
			while(it.hasNext()){
				Triple t = (Triple) it.next();
				System.out.println(t.getIdentifier() + ".");
			}
		}
		else
			System.out.println("<null>");
	}

	public static void executeQueryFile(String fileName){
		try{
			File inputFile = new File(fileName);
			FileReader fileReader = new FileReader(inputFile);
			BufferedReader reader = new BufferedReader(fileReader);
			String queryText = null;
			while((queryText = reader.readLine()) != null){
				String[] queryLine = queryText.split("[\\n\\.]");
				for(String currentLine : queryLine){
					if(currentLine.length() != 0)
						executeQuery(currentLine);
				}
			}
			reader.close();
		}	catch(Exception ex){
				System.out.print("Exception: " + ex);
			}
	}
}
