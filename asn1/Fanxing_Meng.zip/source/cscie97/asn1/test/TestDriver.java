package cscie97.asn1.test;

import cscie97.asn1.knowledge.engine.*;

public class TestDriver{
	public static void main(String[] args){
		Importer.importTripleFile(args[0]);
		QueryEngine.executeQueryFile(args[1]);
	}
}
